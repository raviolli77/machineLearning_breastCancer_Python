
## Example package for the C++ API of `progress`

Progress bars for your C++ code in R packages.
The `progress` package has a pure C++ API for
managing progress bars. This is an example package
that shows how to use it.

The test package uses Rcpp, for simplicity, but this
is not necessary, the API itself does not rely on Rcpp.

# DRR
Dimensionality Reduction via Regression

An implementation of Dimensionality Reduction
via Regression using Kernel Ridge Regression.

## Installing:
```R
## install.packages("devtools")
devtools::install_github("gdkrmr/DRR")
```

Install from CRAN:
```R
install.packages("DRR")
```

Load it:
```R
library(DRR)
```
